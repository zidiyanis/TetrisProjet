#include"fonction.h"

void initialisation(tetris_s* tetris);
void affichage(tetris_s* tetris);
void miseJour(tetris_s* tetris);
