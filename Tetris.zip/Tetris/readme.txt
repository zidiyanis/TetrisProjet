Nous avons essayé de faire le record mais nous n'avons pas réussi, donc nous l'avons enlever.
